# Nerves system image

This is an automatically generated archive created by `nerves_system_br`. It is
useful for building embedded Elixir projects without worrying too much
about the cross-compiler and Linux parts. See http://nerves-project.org
for more information.

## Build information

Configuration: nerves_defconfig
nerves_system_br: v0.6.1-6-g36db413
